﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(WEEK_07.Startup))]
namespace WEEK_07
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
